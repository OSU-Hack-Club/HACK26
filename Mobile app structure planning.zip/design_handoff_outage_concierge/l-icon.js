(function () {
  if (customElements.get('l-icon')) return;
  const pascal = s => s.replace(/(^|-)([a-z0-9])/g, (_, a, b) => b.toUpperCase());
  const queue = [];
  class LIcon extends HTMLElement {
    static get observedAttributes() { return ['name', 'size', 'stroke', 'fill']; }
    connectedCallback() { this.render(); }
    attributeChangedCallback() { if (this.isConnected) this.render(); }
    render() {
      const L = window.lucide;
      if (!L) { queue.push(this); return; }
      const node = L.icons[pascal(this.getAttribute('name') || 'circle')];
      if (!node) { this.replaceChildren(); return; }
      const size = this.getAttribute('size') || '18';
      const svg = L.createElement(node);
      svg.setAttribute('width', size);
      svg.setAttribute('height', size);
      svg.setAttribute('stroke-width', this.getAttribute('stroke') || '2');
      if (this.getAttribute('fill')) svg.setAttribute('fill', this.getAttribute('fill'));
      svg.style.display = 'block';
      this.replaceChildren(svg);
    }
  }
  customElements.define('l-icon', LIcon);
  const s = document.createElement('script');
  s.src = 'https://unpkg.com/lucide@0.460.0/dist/umd/lucide.min.js';
  s.onload = () => { queue.splice(0).forEach(el => el.isConnected && el.render()); };
  document.head.appendChild(s);
})();
