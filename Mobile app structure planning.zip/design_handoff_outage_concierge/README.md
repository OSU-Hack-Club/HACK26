# Handoff: AI Outage Concierge — Mobile Dashboard

## Overview
A mobile app for residential AEP customers before, during and after a storm (HackOHI/O 2026, AEP "AI Outage Concierge" challenge). The home screen opens on a full-bleed **outage map** for the current event. A **glowing status pill** at the top flags new status changes. Below the map are: Status Overview tiles, What Happened, Outage Risk, and Restoration Estimate with a what-if scenario. A persistent **ask bar** at the bottom opens a conversational concierge with plain-language answers. **Settings** sits in the bottom corner and holds the Notifications, Location, Dark Mode and Demo Scenario controls.

Target codebase: `HACK26/` (Next.js 16 App Router, React 19, TypeScript, Tailwind v4, shadcn/ui `base-nova` on Base UI, lucide-react, sonner, next-themes, zod env). **Read `HACK26/AGENTS.md` first.** This Next.js version has breaking changes, so check `node_modules/next/dist/docs/` before writing routes or layouts.

## About the Design Files
The files in this folder are **design references built in HTML**. They are prototypes that show the intended look and behavior, not production code to copy. The task is to **recreate them in the HACK26 codebase** using its existing patterns: shadcn components in `src/components/ui`, the `cn()` helper, Tailwind classes, and lucide-react icons. Note that shadcn here is the Base UI flavor, so compose with the `render` prop, not `asChild`.

Open `ConciergeDashboard.dc.html` in a browser to interact with it. It runs on the bundled `support.js` runtime. The template markup sits in `<x-dc>`, and the logic lives in the `<script data-dc-script>` class at the bottom of the file. All copy, the estimate math and the state transitions are in that class. Port them into TypeScript.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, radii, copy and interactions. Recreate the layout faithfully with the real shadcn components. The tokens already match `src/app/globals.css` exactly; only the concierge additions below are new.

---

## Screens / Views

The app frame is 402×874 (iPhone) or 412×892 (Android). The device bezels (`ios-frame.jsx`, `android-frame.jsx`) are presentation only; don't build them.

### Global layout (column flex, full height)
1. **Header bar**: `bg-background border-b`, padding `6px 12px 10px 16px`.
   - Left: logo slot, 104×44 with `rounded-lg`. Use the official AEP logo asset supplied by the sponsor; don't redraw it.
   - Right: **Status Pill** (see Components).
2. **Body**: a `ScrollArea` (`src/components/ui/scroll-area.tsx`) with `flex-1 min-h-0`. Content uses `px-3 pt-3.5 pb-4`, `flex-col gap-3`.
3. **Bottom bar** (home only): `bg-background border-t px-3 py-2.5 flex-col gap-2`.
   - Row 1: horizontally scrolling quick-question chips.
   - Row 2: the Ask bar (flex-1) plus a 46×46 round outline **Settings** button with the lucide `settings` icon.
4. **Overlays**:
   - Status Sheet: a shadcn `Drawer`, swipe down, 93% height.
   - Chat Sheet: a `Drawer`, 90% height.
   - Toast: `sonner`.
   - Scrim: `bg-black/25` with `backdrop-blur-[2px]`.

### 1. Home (dashboard)
Sections appear in this order. Every section after the map starts with a **Section Header**.

**a. Event Map (first thing on open)**
- Full-bleed: 500px tall, with negative margins to the scroll content's edges, `bg-muted`.
- The map is non-interactive and frames the current event: the outage zone when there is an outage, otherwise the whole circuit. Tapping anything opens the Status Sheet.
- Top overlay row, `top-3 inset-x-3`:
  - Status badge pill: `h-7 rounded-full bg-background ring-1 ring-foreground/10 shadow-sm text-xs font-semibold`, with a 7px dot in the tone color.
  - Weather chip, in the same style.
  - A 34×34 expand button on the right with the `maximize-2` icon.
- **Event Card** overlay: `absolute inset-x-3 bottom-[30px] rounded-2xl bg-background p-3.5 ring-1 ring-foreground/10 shadow-lg flex-col gap-2.5`. It contains:
  - The location line: `map-pin` icon, 12px muted.
  - The title: 20px semibold, tracking `-0.02em`.
  - The estimate line: 13px muted.
  - The legend.
  - A full-width primary Button labeled "View Event Details" with an `arrow-right` icon. It is 40px tall, `bg-primary`, with the label left-aligned.

**b. Status Overview**
- A 2-column grid with `gap-3`.
- KPI tiles are Card-style buttons: min height 104, `p-3 px-3.5`, `rounded-[14px]`.
  - Label: 12px muted with a 13px icon.
  - Value: 20px semibold at the bottom, colored by tone.
  - Sub: 12px muted.
- Tile sets per scenario are listed under State. Tapping a tile opens the related sheet or expands the related section.

**c. What Happened** (Outage and Restoring only)
A Card, `p-4 gap-2.5`, containing:
- The **Confirmed by AEP** badge (see Components).
- A title: 17px semibold.
- A body paragraph, muted.
- A Safety alert: `bg-[--high-bg] text-[--high-ink] rounded-lg p-2.5`, with a `triangle-alert` icon and the text "**Safety:** Stay 30 feet from downed wires, even if they look dead. Call 911."

**d. Need Help?** (Restored only)
A Card with the title "Still in the Dark?", an explanatory paragraph, and an outline Button labeled "Report My Home Is Still Out". The button shows the toast "Got it. A crew will check the line to your home."

**e. Outage Risk** (All Clear and Storm Watch)
A Card containing:
- A kicker row: 13px muted text with the band badge on the right.
- The headline: 24px semibold.
- **10-house pictogram** (Storm Watch only): a 10-column grid, gap 4. Each cell is square and `rounded-lg`. The first *n* cells are filled with the band color and show a `house-plug` icon in white (amber uses dark ink). The rest are outlined with a muted `house` icon.
- A caption: 13px muted.
- An Accordion row, "Why We Think So" (or "Your Line at a Glance" in All Clear). It expands into factor rows:
  - A 30×30 `rounded-lg` icon tile: `trending-up` on `--high-bg`, or `trending-down` on `--low-bg`.
  - A Title Case title and a 13px muted description.
  - A final confidence line with the `gauge` icon.
- **There is no storm-strength slider.** It was removed on purpose.

**f. Restoration Estimate** (Storm Watch, Outage, Restoring)
A Card containing:
- A kicker row with a "Model Estimate" badge: `bg-[--brand-soft] text-[--brand-ink]`, with a `sparkles` icon.
- The headline "Plan to Be Without Power Until {Day h AM}": 22px semibold.
- A sub line: "Most likely back {Tuesday morning}, between X and Y (about a–b hours)."
- A segmented bar: 10px tall, `gap-[3px]`, `rounded-full` segments, widths proportional to hours.
  - Waiting for a crew: `--chart-2`. At 35% opacity once the crew is on site.
  - Clearing roads: `--mid`.
  - Fixing the damage: `--brand`.
- Legend rows with a 10px dot, a label and a right-aligned "~N h" in semibold tabular figures.
- A delta pill when the estimate moved ≥0.5 h from the default inputs: "N h later/sooner than the starting estimate", tinted high or low.
- An Accordion row with a `sliders-horizontal` icon, labeled "Try a What-If". It contains:
  - Steppers for Broken Poles (0–6), Downed Wires (0–10) and Crews Assigned (1–6). Each is two 40×40 outline icon buttons with a value in between.
  - Switch rows for Transformer Damaged and Reroute Power Around the Damage.
  - A ToggleGroup for Road Access (Clear / Some Debris / Trees Down), using `bg-muted p-[3px] rounded-lg` with the active item `bg-background shadow-sm`.
  - A Reset button.

**g. Footnote**: 12px muted with an `info` icon: "Estimates come from a model using past storms and AEP's labor standards. Your home is shown only as an approximate area."

### 2. Status Sheet (opened by the pill, the map or the event card)
A Drawer with a swipe handle (44×5, `bg-muted`, rounded).
- **Header**: a tone badge with the status label, a title (20px semibold), and "Updated {time}" (12px muted). A close button sits on the right.
- **Body** (ScrollArea):
  - **Outage Map**: an interactive map, 300px tall, `rounded-[14px]`, with zoom controls. The legend sits below it.
  - **Confirmed by AEP · {Tag}**: a glowing badge as the section header, then a Card of fact rows (16px icon and text).
  - **Our Estimate**: a block in `bg-[--brand-soft] text-[--brand-ink]` labeled "Model Estimate", with the estimate sentence in 16px semibold.
  - **Updates**: a vertical timeline. Each entry has a 10px dot and a 2px connector. The newest entry is first, with a tone-colored dot, a 3px tone-bg ring and semibold text; older dots use `--chart-1`.
  - A primary brand Button labeled "Ask About This". It opens the chat and asks the time or risk question that fits the current status.
- Opening the sheet marks the current status as **seen**, which stops the pill glow.

### 3. Chat Sheet (Concierge)
- **Header**: a 34px round `brand-soft` avatar with `sparkles`, the title "Outage Concierge", and the sub "{Area} · uses your live estimate".
- **Messages**:
  - User messages are right-aligned bubbles: `bg-[--brand] text-white`, radius `18px 18px 4px 18px`.
  - Bot messages are full-width Cards with radius `16px 16px 16px 4px`. Each has:
    - a "Concierge" label with a status-colored dot;
    - an optional headline (18px semibold);
    - a body (14px);
    - an optional visual: the house pictogram or the time-segment bar;
    - "point" rows (`bg-muted rounded-lg`, with an icon, an uppercase-weight 12px label and 14px text);
    - an optional footnote.
- **Typing state**: a muted pill with a spinning `loader-circle` and "Checking your estimate…". Delay 650 ms.
- **Footer**: quick-question chips, plus a pill input (`rounded-full border-input`, 16px text to avoid iOS zoom) with a 38px round brand send button.
- **Answer rules**: plain language, "about X in 10" instead of percentages, never promise exact times, keep "Confirmed by AEP" separate from "Our best guess", and flag safety items in destructive color. Intents are risk, time, prep, alerts and why, matched by keyword. Unmatched questions go to an LLM call with the current estimate as context and the same rules. If that call fails, show the fallback "I can't answer that one reliably… contact AEP customer service."

### 4. Settings
- A back button "‹ Home" and the title "Settings" (26px semibold, tracking `-0.025em`).
- **Preferences** (one Card, divided rows, each 56px min with a 32px `brand-soft` icon tile):
  - Notifications ›, with the sub "{Storm alerts on | Outage alerts only} · {channels}".
  - Location ›, with the sub "{Area} · {Premise ID}".
  - Dark Mode, with a Switch wired to `next-themes`.
- **Demo**: Demo Scenario chips for All Clear / Storm Watch / Outage Detected / Restoring Power / Power Restored, each with a tone dot. The active chip is `bg-primary`. This is for judges; hide it behind a flag in production.
- **About**: a dashed-border block headed "How We Estimate".

### 5. Settings › Notifications
- **Alert Status**: an eligibility card, `bg-[--low-bg] text-[--low-ink]` when eligible. It shows a bell-ring icon, the headline "You Qualify for Storm Alerts" or "Outage Alerts Only", and a body line.
- **Medical Needs**: a Card row with a `heart-pulse` tile and the label "I Rely on Powered Medical Equipment", plus a Switch.
  - Privacy note: "Only you can turn this on… never shared or shown on any map."
  - Turning it on moves the first alert from 24 h to 48 h ahead, forces Phone Call on (locked, with a toast), and changes the escalation to "call + welfare check at 4 h".
- **How We Reach You**: rows for App Notifications, Text Message (masked number), Email (masked) and Phone Call, each with a Switch.
- **Alert Rules**: check or minus circles for:
  - Outage Chance Is Elevated or High
  - Medical Equipment Declared
  - Phone Number on File
- **When We'll Message You**: a 96px label column for Before a Storm / If It Goes Out / Updates / Escalate, with the value text beside it.
- **Message Previews**: four cards, in this order: Before the Storm, Outage Confirmed, Estimate Updated, Power Restored. Each has:
  - a channel and timing meta line;
  - a status badge (Latest = brand, Sent = primary, Scheduled or Not Needed = secondary);
  - the SMS text in a `bg-muted` bubble with radius `16 16 16 4`;
  - a character and text-segment count;
  - a "Send Me a Test" ghost button.
  - The current card gets a 2px brand ring.
  - The message text is generated live from the estimate.

### 6. Settings › Location
- **Choose Your Location**: a Card list of sample anonymized premises (P-20417 Maple Grove, P-33810 Riverside, P-51122 Ridge Road) plus a premise or circuit ID input with a "Check" button.
- An unknown ID returns to Home and shows the **fallback card**: "We can't make a confident call for "{id}"." with an explanation, the Safety line, and "Choose a Sample Location".
- Privacy note with the `shield-check` icon.

---

## Components

**Section Header**: `flex items-center gap-2.5 pt-2.5 px-1`. The title is 15px semibold, tracking `-0.01em`, nowrap. It is followed by a `flex-1 h-px bg-border` rule. Use it before every grouped section.

**Status Pill** (header):
- Sizing: `h-9 rounded-full pl-3 pr-2.5 gap-2 text-[13px] font-semibold`, with `bg-[tone.bg] text-[tone.ink] border border-[tone.edge]`.
- Contents: an 8px tone dot, the label, and `chevron-down`.
- **When the status has changed and not been seen**, add:
  - **Halo**: an absolutely positioned `inset-[-1px] rounded-full -z-10` element with `box-shadow: 0 0 14px 3px tone.c, 0 0 0 2px tone.edge` and `animation: pill-glow 1.8s ease-in-out infinite`. The keyframes go from opacity .35 at scale 1, to .9 at scale 1.06, and back. The button needs `isolation:isolate`.
  - **Dot ping**: `animation: dot-ping 1.4s cubic-bezier(0,0,.2,1) infinite`, from scale 1 at opacity .8 to scale 2.6 at opacity 0.
- No glow in All Clear.

**Confirmed by AEP badge**:
- Sizing: `h-6 px-2.5 rounded-full text-xs font-semibold`, with a `badge-check` icon.
- Color: `bg-[tone.bg] text-[tone.ink]`, with the glow `box-shadow: 0 0 0 1px tone.edge, 0 0 16px -2px tone.c, 0 0 4px -1px tone.c`.
- Label: "Confirmed by AEP · {Tag}", where Tag is one of No Outages / Storm Watch / Outage / Restoring / Restored.

**Card**: `bg-card text-card-foreground rounded-[14px] ring-1 ring-foreground/10`. The shadcn Card default is `rounded-xl` with the same ring.

**Switch**: 36×20 `rounded-full`. The track is `--brand` when on and `--input` when off. The thumb is 16px white with `shadow-sm` at left 18px (on) or 2px (off), with a 150ms transition. This is the shadcn Switch, sized up for touch.

**Buttons**: primary actions use 44px height (40px in cards), `rounded-lg` (10px), 14px medium text, and a left-aligned label with a trailing icon. Variants: brand fill, `bg-primary`, outline (`border bg-background hover:bg-muted`) and ghost.

**Chips**: `h-8 px-3 rounded-full border text-[13px] font-medium`.

**ScrollArea**: use shadcn's. The scrollbar is a 10px track with 1px padding and a `rounded-full bg-border` thumb, visible on hover or while scrolling. `scroll-area.js` here is a faithful HTML port.

## Outage Map
- Build with **mapcn** (the shadcn map registry, MapLibre GL) or `react-map-gl/maplibre`.
- Basemaps: CARTO Positron (light) and Dark Matter (dark).
- The prototype uses `outage-map.js` with MapLibre 4.7.1.

**Data**: `map-data.json` is extracted from the challenge's `AEP-Challenge-Materials/data/raw/Data1.zip`:
- `lines`: 3,345 simplified CIR2 primary segments, `{u: mainline flag, o: overhead flag, g: [[lng,lat],…]}`.
- `dmg`: 240 ARCOS damage points on CIR2, `{x, y, t: W|P|S|E|L type, r: repaired, d: YYYYMMDD, a: access issue}`.
- `fac`: 3 public fire and ambulance stations.
- `bbox`.

In production, generate this server-side (Route Handler) from the shapefiles, together with `matched_upstream.txt` for real topology.

**Derived at load**:
- `home`: the densest Feb-2025 damage cluster center, offset by about 250 m.
- Per-line `dh`: km from home.
- Per-line `risk`: 0, 1 or 2 from the damage density within 0.7 km of the segment midpoint.
- Outage zones: the convex hull of lines with `dh < 2.5` (outage) or `dh < 1.2` (still out while restoring).
- Home area: a circle of radius 0.45 km. **Never render an exact home pin.**

**Layers by scenario** (map colors are hex because MapLibre can't parse oklch):

| Scenario | Lines | Extras |
|---|---|---|
| normal | `#9aa3af` | home area |
| watch | risk 0 `#1f9d55`, 1 `#e8a100`, 2 `#e0393e` | heatmap of all damage (opacity .5) and facilities |
| outage | `dh<2.5` red, else neutral | zone fill red at 10% with a dashed outline; Feb-2025 damage dots in red with a white stroke; 2 crew truck markers |
| restoring | `dh<1.2` red, `<2.5` green, else neutral | inner zone; near damage red, far damage green; 3 crews |
| restored | `dh<2.5` green | damage dots green |

- Lines have a white (light) or `#171717` (dark) casing underneath at 60% opacity.
- Width interpolates from 0.9 at zoom 10 to 3 at zoom 15.
- The home marker is a 16px brand dot with a 2.5px white border and a pulsing halo (`om-pulse 2.2s`).
- Dark-mode hex values are in `outage-map.js` under `C.dark`.

**Camera**:
- `view="event"` (home screen): fit the zone bounds with padding `{top:60, bottom:230, left:24, right:24}` so the event card doesn't cover the zone.
- `view="circuit"` (sheet): fit with padding 28.
- In All Clear, center on home at zoom 12.1.

**Legend labels** (Title Case) by scenario:

| Scenario | Labels |
|---|---|
| normal | Your Area (Approx.), Your Power Line |
| watch | Lower Risk, Higher Risk, Past Storm Damage, Your Area |
| outage | Outage Area, Reported Damage, Crew, Your Area |
| restoring | Still Out, Restored, Crew, Your Area |
| restored | Restored, Repaired Damage, Your Area |

Line swatches are 16×4; point swatches are 9×9.

## Interactions & Behavior
- Tapping the status pill, the map, "View Event Details" or the expand button opens the Status Sheet and sets `seen = scenario`.
- The ask bar and chips open the Chat Sheet. Chips send their question with a fixed intent. Enter or the send button submits typed text.
- The Settings button opens Settings. The rows push to Notifications or Location. Back buttons pop.
- The accordions ("Why We Think So", "Try a What-If") toggle. KPI tiles open the relevant sheet or accordion.
- What-if inputs recompute the estimate, segments, delta, KPI values, message previews and chat answers live.
- Sheets slide on `transform`, 320 ms, `cubic-bezier(.22,1,.36,1)`. Tapping the scrim closes all sheets.
- Toasts auto-dismiss after 2.2 s.
- Switch knobs move with a 150 ms `left` transition.

## State Management
```ts
scenario: 'normal' | 'watch' | 'outage' | 'restoring' | 'restored' // from the server or a push event in production
seen: Scenario            // last scenario the user opened; glow = scenario !== 'normal' && seen !== scenario
screen: 'home' | 'settings' | 'notifications' | 'location'
statusOpen, chatOpen: boolean
premise: string; unknownId: string | null
poles=2, spans=3, xfmr=false, crews=3, access='clear', reroute=true   // what-if inputs (DEF)
wind = 58 (fixed forecast; no UI)
medical: boolean; ch: { push, sms, email, call }
chat: Message[]; draft: string; typing: boolean
factorsOpen, whatIfOpen: boolean; dark (→ next-themes)
```

**Model** (port `model()` exactly from the DC script):
- **Risk**:
  - `w = clamp((wind-25)/55, 0, 1)`
  - `p = clamp(.05 + .5·w·(overhead ? 1 : .35) + .18·tree·w + (singleFeed ? .07 : 0) + .15·hits/6, .03, .95)`
  - Band: Low below .35, Elevated below .65, else High. `n = round(p·10)`.
- **Labor**:
  - pole 2.50 + 0.93 + 0.59 (crossarm) h, wire span 0.6 h, transformer 2.0 h (from `Install_Labor_HackOHIO.xlsx`).
  - Access adders: +0.5 h per site (limited) or +1.312 h per site (blocked).
- **Repair** = `labor × 4.5 (ILM) / (crews × 3)`, ×0.6 if reroute is possible.
- **Wait** = `1 + 6w (+1.5 if remote)`. **Road** = 4 h (blocked) or 1 h (limited).
- **Range**: ±spread by confidence. Spread is .25, .35 or .5, and .18 while restoring.
- **Outage start**: Mon 9:40 PM.

**KPI tile sets**:

| Scenario | Tiles |
|---|---|
| normal | Outage Chance "Very Low", Alerts "On" |
| watch | Outage Chance "n in 10", If It Goes Out "Until …", Crews Ready "6 Crews", Alerts |
| outage | Status "Out", Likely Back, Homes Out Nearby "1,240", Crews "2 Assigned" |
| restoring | New Estimate, Still Out "410 Homes", Crews "3 On Site", Status |
| restored | Back On {time}, Our Estimate "On Target" |

The homes and crews counts are demo values; replace them with outage-system data.

## Design Tokens
These come from `src/app/globals.css`, **already in the codebase; don't duplicate**:
- `--radius: .625rem`, Geist and Geist Mono.
- `--background oklch(1 0 0)`, `--foreground oklch(.145 0 0)`, `--primary oklch(.205 0 0)`.
- `--muted` / `--secondary` / `--accent` `oklch(.97 0 0)`, `--muted-foreground oklch(.556 0 0)`.
- `--border` / `--input oklch(.922 0 0)`, `--destructive oklch(.577 .245 27.325)`.
- `--chart-1 oklch(.87 0 0)`, `--chart-2 oklch(.556 0 0)`.
- Plus the `.dark` set.

**New tokens to add** to `globals.css` (light / dark):

| Token | Light | Dark |
|---|---|---|
| `--page` (app background behind cards) | `oklch(.985 0 0)` | `oklch(.145 0 0)` |
| `--brand` | `oklch(.50 .16 252)` | `oklch(.64 .15 252)` |
| `--brand-hover` | `oklch(.44 .15 252)` | `oklch(.70 .14 252)` |
| `--brand-soft` | `oklch(.96 .025 252)` | `oklch(.28 .06 252)` |
| `--brand-ink` | `oklch(.42 .14 252)` | `oklch(.82 .1 252)` |
| `--low` | `oklch(.60 .14 150)` | `oklch(.62 .13 150)` |
| `--low-bg` | `oklch(.965 .03 150)` | `oklch(.27 .05 150)` |
| `--low-ink` | `oklch(.42 .1 150)` | `oklch(.85 .1 150)` |
| `--mid` | `oklch(.80 .15 78)` | (same) |
| `--mid-bg` | `oklch(.97 .04 85)` | `oklch(.29 .06 70)` |
| `--mid-ink` | `oklch(.47 .1 62)` | `oklch(.88 .1 82)` |
| `--high` | `= --destructive` | `oklch(.704 .191 22.216)` |
| `--high-bg` | `oklch(.965 .025 27)` | `oklch(.27 .07 25)` |
| `--high-ink` | `oklch(.5 .2 27)` | `oklch(.85 .1 25)` |
| `--ring-card` | `color-mix(in oklch, var(--foreground) 10%, transparent)` | (same) |
| `--shadow-sm` | `0 1px 2px rgb(0 0 0/.06)` | (same) |
| `--shadow-lg` | `0 16px 40px -12px rgb(0 0 0/.28)` | (same) |

`--brand` is a placeholder blue. **Set it to AEP's official brand color** from the sponsor's brand guide.

**Tones** (status → color):

| Status | Tone |
|---|---|
| All Clear / Restored | low (green) |
| Storm Watch | mid (amber) |
| Outage | high (red) |
| Restoring | brand (blue) |

`tone.edge = color-mix(in oklch, tone.c 35%, transparent)` (45% for mid).

**Type scale**:

| Role | Size / weight | Tracking |
|---|---|---|
| Body | 14px / 1.5 | — |
| Small | 12–13px | — |
| Card title | 15–17px semibold | — |
| Headline | 20–24px semibold | −0.02em |
| Page title | 26px semibold | −0.025em |

**Radii**:

| Element | Radius |
|---|---|
| Buttons and inputs | 10px |
| Cards | 14px |
| Event card | 16px |
| Sheets | 20px top corners |
| Pills and chips | full |

**Spacing**: 12px page gutter, 12px gap between cards, 14–16px card padding.

## Copy Rules
- **Title Case** for every title, section header, label, button, badge, tile label or value, legend item, and timeline entry ("Power Outage Detected", "Outage Area", "View Event Details"). Small words (a, an, the, and, or, of, to, in, on, at, for, by) stay lowercase unless they come first.
- **Sentence case** for body text, descriptions, captions and chat answers.
- Separate "Confirmed by AEP" facts from the "Model Estimate" everywhere.

## Assets
- **Icons**: lucide-react. Names used: zap, zap-off, chevron-down, chevron-left, chevron-right, maximize-2, map-pin, arrow-right, arrow-up, sparkles, settings, badge-check, triangle-alert, gauge, trending-up, trending-down, house, house-plug, clock, truck, bell, bell-ring, bell-off, heart-pulse, message-square-text, mail, phone, check, minus, plus, rotate-ccw, sliders-horizontal, info, calculator, moon, sun, wind, cloud-sun, cloud-lightning, circle-check, circle-help, shield-check, tree-pine, wrench, target, send, x, loader-circle, ambulance, flame, list, battery-charging, refrigerator.
- **Logo**: the sponsor-supplied AEP logo, placed in the header slot (104×44, object-fit contain).
- **Map tiles**: © CARTO, © OpenStreetMap contributors. Keep the attribution.
- **Data**: AEP challenge materials (sanitized). Don't expose customer points, crew or employee details, or internal fields.

## Files
- `ConciergeDashboard.dc.html`: the full prototype, with markup, copy and logic (the class at the bottom).
- `outage-map.js`: map component reference (layers, colors, camera, privacy offset).
- `map-data.json`: extracted CIR2 GIS data.
- `scroll-area.js`: ScrollArea behavior reference.
- `shadcn-theme.css`: the token sheet (globals.css plus the concierge additions) and the `pill-glow` / `dot-ping` keyframes.
- `l-icon.js`, `image-slot.js`, `support.js`, `ios-frame.jsx`, `android-frame.jsx`: prototype runtime and presentation only. Don't port these.

## Suggested Implementation Order
1. Add the tokens and keyframes to `globals.css`.
2. Build `lib/estimate.ts`, a port of `model()`, `timeText()` and the messages, with unit tests.
3. Add `app/api/outage/route.ts`, which serves the scenario, facts and map GeoJSON.
4. Build the map with mapcn or MapLibre.
5. Build the Home sections.
6. Build the Status Drawer.
7. Build the Chat Drawer, with `/api/chat` calling Anthropic via `requireEnv("ANTHROPIC_API_KEY")`.
8. Build the Settings routes.
