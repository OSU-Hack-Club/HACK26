// <outage-map scenario="normal|watch|outage|restoring|restored" theme="light|dark" view="home|circuit" interactive="true|false">
// MapLibre GL + CARTO basemaps (the stack shadcn's mapcn uses), drawn from the AEP challenge GIS extract
// (CIR2 primary lines + ARCOS damage points, Feb 2025 storm). The customer's home is shown only as an approximate area.
(function () {
  if (customElements.get('outage-map')) return;
  const V = '4.7.1';
  const SRC = (document.currentScript && document.currentScript.src) || location.href;
  const DATA_URL = new URL('map-data.json', SRC).href;
  const STYLE = { light: 'https://basemaps.cartocdn.com/gl/positron-gl-style/style.json', dark: 'https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json' };
  const C = {
    light: { n: '#9aa3af', low: '#1f9d55', mid: '#e8a100', high: '#e0393e', brand: '#1f5fbf', halo: '#ffffff' },
    dark: { n: '#5f6773', low: '#34c172', mid: '#f2b630', high: '#ff5a5f', brand: '#5b9bff', halo: '#171717' },
  };
  let mlP, dataP;
  const loadML = () => mlP || (mlP = new Promise((res, rej) => {
    if (window.maplibregl) return res(window.maplibregl);
    const l = document.createElement('link'); l.rel = 'stylesheet'; l.href = `https://unpkg.com/maplibre-gl@${V}/dist/maplibre-gl.css`; document.head.appendChild(l);
    const s = document.createElement('script'); s.src = `https://unpkg.com/maplibre-gl@${V}/dist/maplibre-gl.js`; s.onload = () => res(window.maplibregl); s.onerror = rej; document.head.appendChild(s);
  }));
  const st = document.createElement('style');
  st.textContent = `@keyframes om-pulse{0%{transform:scale(.7);opacity:.6}100%{transform:scale(2.6);opacity:0}}
  outage-map{display:block;position:relative;overflow:hidden}
  outage-map .om-root{position:absolute;inset:0}
  outage-map .maplibregl-ctrl-attrib{font-size:9px;line-height:1.3;opacity:.85}
  outage-map .maplibregl-ctrl-bottom-right .maplibregl-ctrl-attrib:not(.maplibregl-compact-show) .maplibregl-ctrl-attrib-inner{display:none}
  outage-map .maplibregl-ctrl-attrib.maplibregl-compact{min-height:18px}
  .om-home{position:relative;width:16px;height:16px}
  .om-home i{position:absolute;inset:0;border-radius:50%;border:2.5px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,.35)}
  .om-home b{position:absolute;inset:0;border-radius:50%;animation:om-pulse 2.2s ease-out infinite}
  .om-pin{width:26px;height:26px;border-radius:50%;display:flex;align-items:center;justify-content:center;box-shadow:0 1px 4px rgba(0,0,0,.3);border:2px solid #fff}`;
  document.head.appendChild(st);

  const km = (a, b) => Math.hypot((a[0] - b[0]) * 111.32 * Math.cos(a[1] * Math.PI / 180), (a[1] - b[1]) * 110.57);
  function hull(pts) {
    pts = pts.slice().sort((a, b) => a[0] - b[0] || a[1] - b[1]);
    const cr = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
    const lo = [], up = [];
    for (const p of pts) { while (lo.length >= 2 && cr(lo[lo.length - 2], lo[lo.length - 1], p) <= 0) lo.pop(); lo.push(p); }
    for (let i = pts.length - 1; i >= 0; i--) { const p = pts[i]; while (up.length >= 2 && cr(up[up.length - 2], up[up.length - 1], p) <= 0) up.pop(); up.push(p); }
    const h = lo.slice(0, -1).concat(up.slice(0, -1)); h.push(h[0]); return h;
  }
  function circle(c, rkm) {
    const out = [];
    for (let i = 0; i <= 48; i++) { const a = i / 48 * 2 * Math.PI; out.push([c[0] + rkm / (111.32 * Math.cos(c[1] * Math.PI / 180)) * Math.cos(a), c[1] + rkm / 110.57 * Math.sin(a)]); }
    return out;
  }
  const loadData = () => dataP || (dataP = fetch(DATA_URL).then(r => r.json()).then(d => {
    const storm = d.dmg.filter(p => p.d.startsWith('202502'));
    let best = storm[0], bc = -1;
    for (const p of storm) { let c = 0; for (const q of storm) if (km([p.x, p.y], [q.x, q.y]) < 0.8) c++; if (c > bc) { bc = c; best = p; } }
    const home = [best.x + 0.0024, best.y - 0.0015];
    const lines = d.lines.map(l => {
      let dh = 1e9; for (const v of l.g) dh = Math.min(dh, km(v, home));
      const mid = l.g[Math.floor(l.g.length / 2)];
      let dens = 0; for (const p of d.dmg) if (km(mid, [p.x, p.y]) < 0.7) dens++;
      return { type: 'Feature', properties: { dh: +dh.toFixed(3), risk: dens < 2 ? 0 : dens < 6 ? 1 : 2 }, geometry: { type: 'LineString', coordinates: l.g } };
    });
    const dmg = d.dmg.map(p => ({ type: 'Feature', properties: { dh: +km([p.x, p.y], home).toFixed(3), t: p.t, storm: p.d.startsWith('202502') ? 1 : 0 }, geometry: { type: 'Point', coordinates: [p.x, p.y] } }));
    const zone = r => { const pts = []; lines.forEach(f => { if (f.properties.dh < r) f.geometry.coordinates.forEach(c => pts.push(c)); }); return pts.length > 2 ? hull(pts) : null; };
    return { home, lines, dmg, fac: d.fac, bbox: d.bbox, zoneOut: zone(2.5), zoneRest: zone(1.2), area: circle(home, 0.45) };
  }));

  class OutageMap extends HTMLElement {
    static get observedAttributes() { return ['scenario', 'theme', 'view']; }
    connectedCallback() {
      if (!this._root) { this._root = document.createElement('div'); this._root.className = 'om-root'; this._markers = []; }
      if (this._root.parentNode !== this) this.appendChild(this._root);
      if (!this._ro) { this._ro = new ResizeObserver(() => this._map && this._map.resize()); }
      this._ro.observe(this);
      if (this._data) { if (!this._map) this.build(); return; }
      if (this._loading) return;
      this._loading = true;
      Promise.all([loadML(), loadData()]).then(([ml, data]) => { this._ml = ml; this._data = data; if (this.isConnected && !this._map) this.build(); }).catch(e => console.warn('outage-map', String(e && (e.message || e.type || e))));
    }
    disconnectedCallback() { this._ro && this._ro.disconnect(); if (this._map) { this._map.remove(); this._map = null; } }
    attributeChangedCallback(n, o, v) {
      if (!this._map || o === v) return;
      if (n === 'theme') this.build(); else if (n === 'view') this.camera(); else this.paint();
    }
    get sc() { return this.getAttribute('scenario') || 'normal'; }
    get th() { return this.getAttribute('theme') === 'dark' ? 'dark' : 'light'; }
    build() {
      if (this._map) { this._map.remove(); this._map = null; }
      if (!this.isConnected || !this._root) return;
      this._markers = [];
      const inter = this.getAttribute('interactive') === 'true';
      const d = this._data;
      this._map = new this._ml.Map({ container: this._root, style: STYLE[this.th], center: d.home, zoom: 12.4, interactive: inter, attributionControl: { compact: true }, dragRotate: false, pitchWithRotate: false, fadeDuration: 0, preserveDrawingBuffer: true, canvasContextAttributes: { preserveDrawingBuffer: true } });
      this._map.on('error', e => console.warn('outage-map error', e && e.error && e.error.message));
      if (inter) this._map.addControl(new this._ml.NavigationControl({ showCompass: false }), 'top-right');
      this._map.on('load', () => { this.paint(); this.camera(true); });
    }
    camera(instant) {
      const m = this._map, d = this._data; if (!m) return;
      const sc = this.sc, view = this.getAttribute('view') || 'home';
      if (view === 'home' || (view === 'event' && sc === 'normal')) { m.jumpTo({ center: [d.home[0] - 0.004, d.home[1] + 0.002], zoom: sc === 'normal' || sc === 'watch' ? 12.1 : 12.5 }); return; }
      const pad = view === 'event' ? { top: 60, bottom: 230, left: 24, right: 24 } : 28;
      const ring = (sc === 'outage' || sc === 'restoring' || sc === 'restored') ? d.zoneOut : null;
      let b;
      if (ring) { const xs = ring.map(p => p[0]), ys = ring.map(p => p[1]); b = [[Math.min(...xs), Math.min(...ys)], [Math.max(...xs), Math.max(...ys)]]; }
      else b = [[d.bbox[0], d.bbox[1]], [d.bbox[2], d.bbox[3]]];
      m.fitBounds(b, { padding: pad, duration: instant ? 0 : 600 });
    }
    clear() {
      const m = this._map;
      ['om-heat', 'om-zone-f', 'om-zone-l', 'om-area-f', 'om-area-l', 'om-lines-c', 'om-lines', 'om-dmg'].forEach(id => m.getLayer(id) && m.removeLayer(id));
      ['om-heat', 'om-zone', 'om-area', 'om-lines', 'om-dmg'].forEach(id => m.getSource(id) && m.removeSource(id));
      this._markers.forEach(mk => mk.remove()); this._markers = [];
    }
    marker(ll, el) { const mk = new this._ml.Marker({ element: el }).setLngLat(ll).addTo(this._map); this._markers.push(mk); }
    pin(bg, icon, fg) {
      const el = document.createElement('div'); el.className = 'om-pin'; el.style.background = bg; el.style.color = fg || '#fff';
      el.innerHTML = `<l-icon name="${icon}" size="13" stroke="2.5"></l-icon>`; return el;
    }
    paint() {
      const m = this._map, d = this._data; if (!m || !m.isStyleLoaded()) return;
      this.clear();
      const sc = this.sc, k = C[this.th];
      const fc = f => ({ type: 'geojson', data: { type: 'FeatureCollection', features: f } });
      const poly = r => fc(r ? [{ type: 'Feature', properties: {}, geometry: { type: 'Polygon', coordinates: [r] } }] : []);
      if (sc === 'watch') {
        m.addSource('om-heat', fc(d.dmg));
        m.addLayer({ id: 'om-heat', type: 'heatmap', source: 'om-heat', paint: { 'heatmap-radius': ['interpolate', ['linear'], ['zoom'], 10, 10, 14, 28], 'heatmap-intensity': 0.7, 'heatmap-opacity': 0.5, 'heatmap-color': ['interpolate', ['linear'], ['heatmap-density'], 0, 'rgba(0,0,0,0)', 0.3, k.mid, 0.8, k.high] } });
      }
      const zr = sc === 'outage' ? d.zoneOut : sc === 'restoring' ? d.zoneRest : null;
      m.addSource('om-zone', poly(zr));
      m.addLayer({ id: 'om-zone-f', type: 'fill', source: 'om-zone', paint: { 'fill-color': k.high, 'fill-opacity': 0.1 } });
      m.addLayer({ id: 'om-zone-l', type: 'line', source: 'om-zone', paint: { 'line-color': k.high, 'line-width': 1.5, 'line-opacity': 0.7, 'line-dasharray': [2, 2] } });
      const color = {
        normal: k.n,
        watch: ['match', ['get', 'risk'], 0, k.low, 1, k.mid, k.high],
        outage: ['case', ['<', ['get', 'dh'], 2.5], k.high, k.n],
        restoring: ['case', ['<', ['get', 'dh'], 1.2], k.high, ['<', ['get', 'dh'], 2.5], k.low, k.n],
        restored: ['case', ['<', ['get', 'dh'], 2.5], k.low, k.n],
      }[sc];
      m.addSource('om-lines', fc(d.lines));
      m.addLayer({ id: 'om-lines-c', type: 'line', source: 'om-lines', layout: { 'line-cap': 'round', 'line-join': 'round' }, paint: { 'line-color': k.halo, 'line-width': ['interpolate', ['linear'], ['zoom'], 10, 2, 15, 5], 'line-opacity': 0.6 } });
      m.addLayer({ id: 'om-lines', type: 'line', source: 'om-lines', layout: { 'line-cap': 'round', 'line-join': 'round' }, paint: { 'line-color': color, 'line-width': ['interpolate', ['linear'], ['zoom'], 10, 0.9, 15, 3] } });
      m.addSource('om-area', poly(d.area));
      m.addLayer({ id: 'om-area-f', type: 'fill', source: 'om-area', paint: { 'fill-color': k.brand, 'fill-opacity': 0.12 } });
      m.addLayer({ id: 'om-area-l', type: 'line', source: 'om-area', paint: { 'line-color': k.brand, 'line-width': 1.5, 'line-opacity': 0.8 } });
      if (sc === 'outage' || sc === 'restoring' || sc === 'restored') {
        m.addSource('om-dmg', fc(d.dmg.filter(f => f.properties.storm && f.properties.dh < 2.5)));
        const dc = sc === 'outage' ? k.high : sc === 'restored' ? k.low : ['case', ['<', ['get', 'dh'], 1.2], k.high, k.low];
        m.addLayer({ id: 'om-dmg', type: 'circle', source: 'om-dmg', paint: { 'circle-radius': ['interpolate', ['linear'], ['zoom'], 10, 2.5, 15, 6], 'circle-color': dc, 'circle-stroke-color': k.halo, 'circle-stroke-width': 1.5 } });
      }
      if (sc === 'outage' || sc === 'restoring') {
        const cand = d.dmg.filter(f => f.properties.storm && f.properties.dh > 0.4 && f.properties.dh < (sc === 'outage' ? 2.2 : 1.1)).sort((a, b) => a.properties.dh - b.properties.dh);
        const picks = []; for (const f of cand) { if (picks.every(p => km(p, f.geometry.coordinates) > 0.6)) picks.push(f.geometry.coordinates); if (picks.length === (sc === 'outage' ? 2 : 3)) break; }
        picks.forEach(p => this.marker(p, this.pin(k.brand, 'truck')));
      }
      if (sc !== 'normal') d.fac.forEach(f => this.marker([f.x, f.y], this.pin(this.th === 'dark' ? '#262626' : '#ffffff', f.k === 'A' ? 'ambulance' : f.k === 'H' ? 'hospital' : 'flame', this.th === 'dark' ? '#e5e5e5' : '#404040')));
      const h = document.createElement('div'); h.className = 'om-home'; h.innerHTML = `<b style="background:${k.brand}"></b><i style="background:${k.brand}"></i>`;
      this.marker(d.home, h);
      this.camera(true);
    }
  }
  customElements.define('outage-map', OutageMap);
})();
