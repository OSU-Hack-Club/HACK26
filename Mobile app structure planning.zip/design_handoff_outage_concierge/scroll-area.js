// <scroll-area> — mirrors src/components/ui/scroll-area.tsx (Base UI ScrollArea):
// hidden native scrollbar, 10px track with 1px padding, rounded-full bg-border thumb,
// visible on hover / while scrolling.
(function () {
  if (customElements.get('scroll-area')) return;
  class ScrollArea extends HTMLElement {
    constructor() {
      super();
      const r = this.attachShadow({ mode: 'open' });
      r.innerHTML = `<style>
        :host{display:block;position:relative;overflow:hidden;min-height:0}
        .vp{height:100%;width:100%;overflow-y:auto;overflow-x:hidden;scrollbar-width:none;overscroll-behavior:contain;-webkit-overflow-scrolling:touch}
        .vp::-webkit-scrollbar{display:none}
        .bar{position:absolute;top:0;right:0;bottom:0;width:10px;padding:1px;box-sizing:border-box;border-left:1px solid transparent;opacity:0;transition:opacity .25s;touch-action:none;z-index:5}
        :host(:hover) .bar,.bar.on{opacity:1}
        .bar.hide{display:none}
        .th{position:absolute;left:1px;right:1px;border-radius:999px;background:var(--border,#e5e5e5);cursor:grab}
        .th:hover{background:color-mix(in oklch,var(--muted-foreground,#888) 55%,transparent)}
      </style><div class="vp" part="viewport"><slot></slot></div><div class="bar"><div class="th"></div></div>`;
      this.vp = r.querySelector('.vp');
      this.bar = r.querySelector('.bar');
      this.th = r.querySelector('.th');
      this.update = this.update.bind(this);
    }
    connectedCallback() {
      this.vp.addEventListener('scroll', () => { this.update(); this.flash(); }, { passive: true });
      this.ro = new ResizeObserver(this.update);
      this.ro.observe(this.vp);
      this.mo = new MutationObserver(() => requestAnimationFrame(this.update));
      this.mo.observe(this, { childList: true, subtree: true });
      this.th.addEventListener('pointerdown', e => {
        e.preventDefault();
        const y0 = e.clientY, s0 = this.vp.scrollTop;
        const ratio = this.vp.scrollHeight / this.vp.clientHeight;
        const mv = ev => { this.vp.scrollTop = s0 + (ev.clientY - y0) * ratio; };
        const up = () => { window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up); };
        window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
      });
      requestAnimationFrame(this.update);
    }
    disconnectedCallback() { this.ro && this.ro.disconnect(); this.mo && this.mo.disconnect(); }
    flash() { this.bar.classList.add('on'); clearTimeout(this._t); this._t = setTimeout(() => this.bar.classList.remove('on'), 700); }
    update() {
      const { scrollHeight: sh, clientHeight: ch, scrollTop: st } = this.vp;
      if (sh <= ch + 1) { this.bar.classList.add('hide'); return; }
      this.bar.classList.remove('hide');
      const track = this.bar.clientHeight - 2;
      const h = Math.max(24, track * ch / sh);
      this.th.style.height = h + 'px';
      this.th.style.top = (1 + (track - h) * st / (sh - ch)) + 'px';
    }
    get scrollTop() { return this.vp.scrollTop; }
    set scrollTop(v) { this.vp.scrollTop = v; }
    get scrollHeight() { return this.vp.scrollHeight; }
    scrollTo(o) { this.vp.scrollTo(o); }
  }
  customElements.define('scroll-area', ScrollArea);
})();
